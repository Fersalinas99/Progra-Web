
import javax.swing.JOptionPane;
public class Tarea_11{
	public static void main(String[]args){
		String game="";
		int respuesta;
		do{
	int n,i=1,j=1,z,x=2;
		String entrada;
        String letrero="";
		entrada= JOptionPane.showInputDialog("Ingrese la cantidad de numeros deseadas");
		n=Integer.parseInt(entrada);

		while(i<=n){
            if(j%2!=0){  
                letrero= letrero+"-"+j;
								i=i+1;
            }else{
                for(z=1;z<=x;z++){
                    letrero= letrero+","+j;
										i++;
										if(i>n){
											break;}
                }
                x++;
            }
						j++;
	}
        JOptionPane.showMessageDialog(null,"La sucesion es:\n"+letrero+".");
		
		 game="";
	         game=game+"1. Volver realizar\n";
	         game=game+"2. Finalizar\n";
	         game=JOptionPane.showInputDialog(game+"Que desea realizar: ");
	         respuesta=Integer.parseInt(game);
	         }while(respuesta==1);
		
		
	} //Fin de main 
}    // Fin clase