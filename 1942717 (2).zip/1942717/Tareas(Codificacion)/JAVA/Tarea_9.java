

import javax.swing.JOptionPane;
import java.lang.System;
public class Tarea_9{
   public static void main (String[]args){
	   String entrada;
	   String game="";
	   int respuesta;
	   do{
		   
	   double moneda,c;
	   double dolar=0.052;
	   double euro=0.047;
	   double yen=5.7;
	   double dolarhk=0.41;
	   c=0;
	   String[] options={"DOLAR","EURO","YEN","DOLAR-HK","Cancelar"};
          int opcion=JOptionPane.showOptionDialog(null,"Selecciona un tipo de moneda", 
		  "Numeros", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[4]);
	  	
	  
		 
		 switch(opcion){
			  
			 case 0: 
			     JOptionPane.showMessageDialog(null,"1 Peso equivale a 0.052 Dolares");
			     entrada=JOptionPane.showInputDialog("Ingresa una cantidad en pesos mexicanos: ");
		             moneda=Double.parseDouble(entrada);
				     c=moneda*dolar;
		                 JOptionPane.showMessageDialog(null,moneda+" MXN son "+c+" Dolares.");
		     break;
			 case 1: 
			     JOptionPane.showMessageDialog(null,"1 Peso equivale a 0.047 Euros");
			     entrada=JOptionPane.showInputDialog("Ingresa una cantidad en pesos mexicanos: ");
		             moneda=Double.parseDouble(entrada);
			         c=moneda*euro;
				         JOptionPane.showMessageDialog(null,moneda+" MXN son "+c+" Euros.");
			 break;
			 case 2: 
			     JOptionPane.showMessageDialog(null,"1 Peso equivale a 5.70 Yenes");
			     entrada=JOptionPane.showInputDialog("Ingresa una cantidad en pesos mexicanos: ");
		             moneda=Double.parseDouble(entrada);
			         c=moneda*yen;
			             JOptionPane.showMessageDialog(null,moneda+"MXN son "+c+" Yenes.");
			 break;
			 case 3: 
			     JOptionPane.showMessageDialog(null,"1 Peso equivale a 0.41 Dolares HK");
			     entrada=JOptionPane.showInputDialog("Ingresa una cantidad en pesos mexicanos: ");
		             moneda=Double.parseDouble(entrada);
			         c=moneda*dolarhk;
				         JOptionPane.showMessageDialog(null,moneda+" MXN son "+c+" Dolar HK.");
			 break;
		 }
		 
		     game="";
	         game=game+"1. Volver realizar\n";
	         game=game+"2. Finalizar\n";
	         game=JOptionPane.showInputDialog(game+"Que desea realizar: ");
	         respuesta=Integer.parseInt(game);
	         }while(respuesta==1);
		 
} //Fin de main
} //Fin clase 