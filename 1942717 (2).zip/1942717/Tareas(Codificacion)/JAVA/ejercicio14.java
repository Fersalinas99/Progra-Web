package ejercicio14;
import java.util.*;
public class ejercicio14 {
    public static void main(String[] args) {
        double tp,tp1 = 0;
        char c;
         Scanner data = new Scanner(System.in);
        
          
       
       System.out.println("Ingresar total a pagar  ");
      tp=data.nextDouble();   
         
      System.out.println("Ingresa color  ");
      c=data.next().charAt(0);
        
         if(c == 'b')
          tp1=tp/1;      
         else if (c == 'v')
          tp1=tp-(tp*0.1);
         else if(c == 'd')
           tp1=tp-(tp*0.25);
         else if (c == 'a')
           tp1=tp-(tp*1);
         
        System.out.println("El monto a pagar es de " + tp1); 
         
    }   
}