

import java.util.Scanner;
import javax.swing.JOptionPane;
public class Tarea_14{
     public static void main (String[]args){
	 String entrada;
	 String game="";
	 int respuesta;
	 do{
	 String elementos;
	 String letrero="";
	 int fil,col,i,j,valores,b,num=0;
	 
	 JOptionPane.showMessageDialog(null,"Busqueda en Matriz.");
	 
	 entrada=JOptionPane.showInputDialog("Ingresar el numero de filas");
	 fil=Integer.parseInt(entrada);
	 entrada=JOptionPane.showInputDialog("Ingresar el numero de columnas");
	 col=Integer.parseInt(entrada);
	 int a[][]=new int[fil][col];
	 
	     for(i=0;i<fil;i++){
			 for(j=0;j<col;j++){
			     elementos=JOptionPane.showInputDialog("Elemento de la posicion ["+i+"]["+j+"]:");
				 valores=Integer.parseInt(elementos);
				 a[i][j]=valores;
			 }
		 }
		 for(i=0;i<fil;i++){
			 for(j=0;j<col;j++){
				 letrero=letrero+"["+a[i][j]+"]   \t";
			 }
			 letrero=letrero+"\n";
		 }
		 entrada=JOptionPane.showInputDialog("Valor a buscar:");
		 b=Integer.parseInt(entrada);
		 for(i=0;i<fil;i++){
			 for(j=0;j<col;j++){
				 if(b==a[i][j]){
					 num=num+1;
				 }
			 }
		 }
		 JOptionPane.showMessageDialog(null,"El numero "+b+" aparece "+ num+" veces en la matriz: \n"+letrero);
		 
		     game="";
	         game=game+"1. Volver realizar\n";
	         game=game+"2. Finalizar\n";
	         game=JOptionPane.showInputDialog(game+"Que desea realizar: ");
	         respuesta=Integer.parseInt(game);
	         }while(respuesta==1);
			 
		 
} //Fin de main
} //Fin clase