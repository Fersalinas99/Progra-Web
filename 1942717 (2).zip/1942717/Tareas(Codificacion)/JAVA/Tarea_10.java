

import javax.swing.JOptionPane;
import java.lang.Math;
public class Tarea_10{
     public static void main (String[]args){
	     String entrada;
		 String game="";
		 int respuesta;
			JOptionPane.showMessageDialog(null, "Serie A");
			do{
				
		    int n,x;
			double i,num;
			String letrero="";
			
			
			entrada=JOptionPane.showInputDialog("Ingresar el total de numeros");   
			n=Integer.parseInt(entrada);
				for(i=1;i<=n;i++){
				   num=Math.pow(i,(2*i-1));
				   if(i==n){
					   letrero=letrero+num+".";
				   }else{
					   letrero=letrero+num+", ";
				   }
				}
				   JOptionPane.showMessageDialog(null, letrero);
					
			 game="";
	         game=game+"1. Volver realizar\n";
	         game=game+"2. Finalizar\n";
	         game=JOptionPane.showInputDialog(game+"Que desea realizar: ");
	         respuesta=Integer.parseInt(game);
	         }while(respuesta==1);
			 
} //Fin de main
} //Fin clase



