
import javax.swing.JOptionPane;
import java.lang.System;
public class Tarea_8{
public static void main (String[]args){
	     String temperatura;
	     double grados,t;
		 String game="";
	     int respuesta;
	     do{
	     String[] options={"\u2109","\u2103","Cancelar"};
        
		
			 int opcion=JOptionPane.showOptionDialog(null," A que temperatura a convertir", 
		     "Tipo de Temperatura", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[2]);
	  	      
			
		     switch(opcion){
				 
			 case 0:temperatura=JOptionPane.showInputDialog("Ingresa la temperatura en \u2103: ");
			        grados=Double.parseDouble(temperatura);
		            t=(grados*9/5)+32;
		            JOptionPane.showMessageDialog(null,grados+"\u2103 son "+t+" \u2109");
		     break;
		     case 1:temperatura=JOptionPane.showInputDialog("Ingrese la temperatura \u2109: ");
			        grados=Double.parseDouble(temperatura);
			        t=(grados-32)*5/9;
			        JOptionPane.showMessageDialog(null,grados+"\u2109 son "+t+" \u2103");
			 break;
		     }
	         
	         game="";
	         game=game+"1. Volver realizar\n";
	         game=game+"2. Finalizar\n";
	         game=JOptionPane.showInputDialog(game+"Que desea realizar: ");
	         respuesta=Integer.parseInt(game);
	         }while(respuesta==1);
	   
} //Fin de main
} //Fin clase 