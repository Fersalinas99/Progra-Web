

import javax.swing.JOptionPane;
public class Tarea_16{
	public static void main(String[] args){
		
		String entrada;
		String game="";
		int respuesta;
		JOptionPane.showMessageDialog(null,"Multiplicacion de Matrices.");
		do{
		int a[][],b[][],c[][],i,j,fila,cola,filb,colb,resultado,k;
		

		entrada=JOptionPane.showInputDialog("Numero de Filas de la Matriz A:");
		fila=Integer.parseInt(entrada);
		entrada=JOptionPane.showInputDialog("Numero de Columnas de la Matriz A:");
		cola=Integer.parseInt(entrada);
		a=new int[fila][cola];
		for(i=0;i<fila;i++){ 
			for(j=0;j<cola;j++){
			entrada=JOptionPane.showInputDialog("Ingrese Elemento de la Matriz A de la Posicion ["+i+"]["+j+"]:");
			a[i][j]=Integer.parseInt(entrada);
		}
		}
			
		entrada=JOptionPane.showInputDialog("Numero de Filas de la Matriz B:");
		filb=Integer.parseInt(entrada);
		entrada=JOptionPane.showInputDialog("Numero de Columnas de la Matriz B:");
		colb=Integer.parseInt(entrada);
		b=new int[filb][colb];
		for(i=0;i<filb;i++){
			for(j=0;j<colb;j++){
			entrada=JOptionPane.showInputDialog("Ingrese Elemento de la Matriz B de la Posicion ["+i+"]["+j+"]:");
			b[i][j]=Integer.parseInt(entrada);
			}
		}
		
		c=new int[fila][colb];
		if(cola==filb){
			for(i=0;i<fila;i++){
				for(j=0;j<colb;j++){
					for(k=0;k<cola;k++){
						c[i][j]+=a[i][k]*b[k][j];
					}
				}
			}
		
		String letrero="";
		for(i=0;i<fila;i++){
				for(j=0;j<colb;j++){
					
					letrero=letrero+"[ "+c[i][j]+" ]   ";
					}
				letrero=letrero+"\n";
			}
			
		JOptionPane.showMessageDialog(null,"La Multiplicacion de las Matrices A y B es igual: \n"+letrero);
		
        	}else{
			JOptionPane.showMessageDialog(null,"No es Posible Hacer la Multiplicacion Porque la Columna de la Matriz A es diferentes a la Fila de la Matriz B");
		}
		
		     game="";
	         game=game+"1. Volver realizar\n";
	         game=game+"2. Finalizar\n";
	         game=JOptionPane.showInputDialog(game+"Que desea realizar: ");
	         respuesta=Integer.parseInt(game);
	         }while(respuesta==1);
		
}//fin de main
}//fin de clase