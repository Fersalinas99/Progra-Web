import javax.swing.JOptionPane;
public class Tarea_13{
     public static void main (String[]args){
	     String entrada;
		 String game="";
		 JOptionPane.showMessageDialog(null,"Busqueda en vector");
		 int respuesta;
		 do{
		    int i,n,x=10000,b,j,cont=0;
			int arre[]=new int[x];
			String letrero="";
			String buscar="";
			
			 entrada=JOptionPane.showInputDialog("Cuantos numeros desea ingresar:");
			 n=Integer.parseInt(entrada);
	     
             for(i=0;i<n;i++){
				 entrada=JOptionPane.showInputDialog("Ingresar el numero de la posicion "+(i+1));
				     arre[i]=Integer.parseInt(entrada);
			 }
			 for(i=0;i<n;i++){
				 letrero=letrero+"["+arre[i]+"]";
			 }
			 
			 JOptionPane.showMessageDialog(null,"Haz completado los valores");
			 entrada=JOptionPane.showInputDialog("Valor a buscar: ");
			 x=Integer.parseInt(entrada);
			     for(i=0;i<n;i++){
				     if(x==arre[i]){
				         cont=cont+1;
					 }
				 }
				 JOptionPane.showMessageDialog(null,"El numero "+x+" aparece "+ cont+" veces\n"+letrero);
				 
			 game="";
	         game=game+"1. Volver realizar\n";
	         game=game+"2. Finalizar\n";
	         game=JOptionPane.showInputDialog(game+"Que desea realizar: ");
	         respuesta=Integer.parseInt(game);
	         }while(respuesta==1);
	 
} //Fin de main
} //Fin clase