
import javax.swing.JOptionPane;
public class Tarea_12{
	public static void main(String[]args){
		String game="";
		int respuesta;
		do{
		int n, i, j, x, pos, neg, opcion;
		String entrada;
		
			i=2; x=2;
	    String letrero="";
			entrada= JOptionPane.showInputDialog("Ingrese la cantidad de numeros deseada");
			n=Integer.parseInt(entrada);
      if(n>0){
				pos= 2; 
				neg= -3; 
				letrero= letrero+pos;
				while(i<=n){
					for(j=1;j<=3;j++){ 
						if(i<=n){ 
							letrero= letrero+", "+neg;
							neg-=2;
							i++;
						} 
					} 
					for(j=1;j<=x;j++){ 
						if(i<=n){ 
							pos=pos+2;
							letrero= letrero+", "+pos;
							i++;
						} 
					}
					x++; 
				} 
			}else{  
        letrero="0";
      } 
      JOptionPane.showMessageDialog(null,"La sucesion es:\n"+letrero+".");
	  
	  game="";
	         game=game+"1. Volver realizar\n";
	         game=game+"2. Finalizar\n";
	         game=JOptionPane.showInputDialog(game+"Que desea realizar: ");
	         respuesta=Integer.parseInt(game);
	         }while(respuesta==1);
			
	}//Fin de main
} //Fin de main
