
puts ("Busqueda en Matriz.")

begin

print ("Ingrese el numero de filas: ")
    fil=gets().to_i
print ("Ingrese el numero de columnas: ")
    col=gets().to_i

a=Array.new(fil){Array.new(col)}

   for i in(0...fil)
       for j in(0...col)
	      print ("Ingresa el valor de la posicon #{[i]}#{[j]}: ")
	         a[i][j]=gets().to_i
	   end
   end
 
letrero=""
   for i in(0...fil)
       for j in(0...col)
	       letrero=letrero+a[i][j].to_s+"  "
	    end
	       letrero=letrero+"\n"
   end

begin

   num=0
   print ("\tValor a buscar: ")
       x=gets().to_i
   for i in(0...fil)
      for j in(0...col)
	     if (x==a[i][j])
		    num+=1
		 end	
	  end   	
   end  	
    
    puts ("El numero #{x} aparece #{num} veces")
    puts (letrero)

      print "\nDesea buscar otro valor. \n\tOpcion 1. Si:\n\tOpcion 2. No:  "
      respuesta=gets().to_i
   end while respuesta==1	
   
      print "\nDesea realizarlo otra vez. \n\tOpcion 1. Si:\n\tOpcion 2. Finalizar:  "
      respuesta=gets().to_i
   end while respuesta==1
			
			
			