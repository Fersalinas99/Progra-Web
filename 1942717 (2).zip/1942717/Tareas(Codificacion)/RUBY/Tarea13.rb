puts ("Busqueda de vector")

begin

print ("Cuantos numeros desea ingresar: ")
    n=gets().to_i
a=Array.new(n)

for i in(0...n)
    print ("Ingresar un numero: ")
    a[i]=gets().to_i
end 

letrero="A=["
    for i in(0...n)
    end
    letrero=letrero+"]"

cont=0
    puts ("Haz completado los valores")
    print ("Ingresa el valor a buscar: ")
        x=gets().to_i
        for i in(0...n)   
            if (x==a[i])
               cont+=1
            end
        end
        
		print ("\nEl numero #{x} aparece #{cont} veces.\n")
   
      print "\nDesea realizarlo otra vez. \n1.Si:\n2.No: "
      respuesta=gets().to_i
end while respuesta==1