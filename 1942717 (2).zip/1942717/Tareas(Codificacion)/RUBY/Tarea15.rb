puts ("Suma de Matrices.")
begin

print ("Ingrese el numero de filas de la Matriz A: ")
    fila=gets().to_i
print ("Ingrese el numero de columnas de la Matriz A: ")
    cola=gets().to_i

a=Array.new(fila){Array.new(cola)}

    for i in(0...fila)
       for j in(0...cola)
	      print ("Matriz A - Ingresa el valor de la posicion #{[i]}#{[j]}: ")
	         a[i][j]=gets().to_i
	   end
    end


print ("Ingresa el numero de filas de la Matriz B: ")
    filb=gets().to_i
print ("Ingresa el numero de columnas de la matriz B: ")
    colb=gets().to_i

   

b=Array.new(filb){Array.new(colb)}

    for i in(0...filb) 
       for j in(0...colb)
	      print ("Matriz B - Ingresa el valor de la posicion #{[i]}#{[j]}: ")
		     b[i][j]=gets().to_i
	   end
    end	  

c=Array.new(fila){Array.new(colb)}
    if(fila==filb && cola==colb)
       for i in(0...fila)
	      for j in(0...cola)
		     c[i][j]=a[i][j]+b[i][j]
		  end
	   end
    end
		 
   letrero=""
       for i in(0...fila)
           for j in(0...cola)
	           letrero=letrero+c[i][j].to_s+"  "
	       end
	       letrero=letrero+"\n"
       end
  
   puts ("La suma de las matrices A y B es:\n#{letrero}")

       print "\nDesea realizarlo otra vez. \n\tOpcion 1. Si:\n\tOpcion 2. No:  "
       respuesta=gets().to_i
           end while respuesta==1
   
			