
puts "Serie A"

begin

print ("Ingrese el total de numeros de la serie: ")
    n=gets().to_i
puts "\n"

    for i in(-1..n)
        serie=(i*(2*i))
	    letrero=""
	    if (i==n)
	        puts ("#{serie}.")
	    else
	        print ("#{serie}, ")
	    end
    end
	
	  print "\nDesea realizarlo otra vez. \n1.Si:\n2.No: "
      respuesta=gets().to_i
end while respuesta==1
