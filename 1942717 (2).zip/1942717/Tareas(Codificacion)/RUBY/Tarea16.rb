puts ("Multiplicacion de Matrices")

begin

print ("Ingrese el numero de filas de las matrices: ")
    fil=gets().to_i
print ("Ingrese el numero de columnas de las matrices: ")
    col=gets().to_i

    if(fil != col)
        puts ("Debe ser matriz regular")

    else

a=Array.new(fil){Array.new(col)}
   
    puts ("Matriz A")
       for i in(0...fil)
	      for j in(0...col)
		     print ("Ingrese el valor de la posicion #{[i]}#{[j]}:  ")
			 a[i][j]=gets().to_i
		  end
       end
	  
b=Array.new(fil){Array.new(col)}
      
    puts ("Matriz B")
       for i in(0...fil)
	      for j in(0...col)
		     print ("Ingrese el valor de la posicion #{[i]}#{[j]}:  ")
		     b[i][j]=gets().to_i
		  end
	   end
	  
c=Array.new(fil){Array.new(col)}

       for i in(0...fil)
	      for j in(0...col)
		     c[i][j]=0
			 for k in(0...col)
			    c[i][j]+=(a[i][k]*b[k][j])
			 end
		  end
	   end
	   
	   
letrero=""
    for i in(0...fil)
       for j in(0...col)
	      letrero=letrero+c[i][j].to_s+"  "
	   end
	   letrero=letrero+"\n"
    end
    
	puts ("La multiplicarion de las matrices A y B es:\n#{letrero}")
    
	end
    
 	  print "\nDesea realizarlo otra vez. \n\tOpcion 1. Si\n\tOpcion 2. No:  "
      respuesta=gets().to_i
end while respuesta==1
	  
			
			
			
			
			
			
			
			
			
			
			
			
			