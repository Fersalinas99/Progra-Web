puts "Serie B"

begin

	i= 2
	l= 2
	m= 2
  print("Ingrese el total de numeros de la serie: ")
  x= gets().to_i
  letrero=""
	if(x>0) then
    letrero= letrero+"-1"
		while (i<=x)
		if (l%2!=0) then
        letrero= letrero+", -#{l}" 
        i+=1
     else
        for z in(1..m)
          if (i<=x) then 
            letrero= letrero+", #{l}"
            i+=1
          end 
        end
        m+=1
		end 
			l+=1
		end 
	else 
    letrero= "0"
  end 
  print("\nLa sucesion de números va:\n"+letrero+".")
  
    print "\nDesea realizarlo otra vez. \n1.Si:\n2.No: "
      respuesta=gets().to_i
end while respuesta==1

