puts "Serie C"

begin

  i= 2
  x= 2
  print("Ingrese el total de numeros de la serie: ")
  n= gets().to_i
  letrero=""
  if(n>0) then
    positivo= 2 
    negativo=-3 
    letrero= letrero+"#{positivo}"
			while (i<=n)
				for j in(1..3) 
        if(i<=n) then 
          letrero= letrero+", #{negativo}"
          negativo-=2
          i+=1
        end 
				end 
				for j in(1..x) 
        if (i<=n) then 
          positivo+=2
          letrero= letrero+", #{positivo}"
          i+=1
        end 
				end 
      x+=1
			end 
			else 
			letrero= "0"
	end 
	print("\nLa sucesion de números va:\n"+letrero+".")
	
	  print "\nDesea realizarlo otra vez. \n1.Si:\n2.No: "
      respuesta=gets().to_i
end while respuesta==1
 