

puts ("Conversion de temperatura")

begin

print "\n\tOpcion 1. °C a °F\n\tOpcion 2. °F a °C\n\nA que tipo de temperatura deseas convertir: "
    opcion=gets().to_f

case opcion
    when 1
        print "Ingresa tu temperatura en °C: "
            grados=gets().to_f
	            t=((grados*9/5)+32)
	            puts (t)
    when 2
        print "Ingresa tu temperatura en °F: "
	        grados=gets().to_f
	            t=((grados-32)*5/9);
	            puts (t)
    else
        puts ("Escribiste una opcion invalida")
end
   
      print "\nDesea realizarlo otra vez. \n1.Si:\n2.No: "
      respuesta=gets().to_i
end while respuesta==1


  