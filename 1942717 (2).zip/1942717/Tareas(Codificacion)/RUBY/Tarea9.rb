puts ("Conversion de pesos mexicanos\n\n")

begin

print "\t Opcion 1. Dolar.\n\t Opcion 2. Euro.\n\t Opcion 3. Yen.\n\t Opcion 4. Dolar HK\n\nA que moneda deseas convertir: "
    opcion=gets().to_f

dolar=0.052
euro=0.047
yen=5.7
dolarhk=0.41

   case opcion
      when 1
	     puts ("1 Peso equivale a 0.052 Dolares")
		 print ("Ingresa una cantidad en pesos mexicanos: ")
		    moneda=gets().to_i
		    c=moneda*dolar
			   puts ("\t#{moneda} MXN son #{c} Dolares.")
     
      when 2
	     puts ("1 Peso equivale a 0.047 Euros")
		 print ("Ingresa una cantidad en pesos mexicanos: ")
		    moneda=gets().to_i
			c=moneda*euro
			    puts ("\t#{moneda} MXN son #{c} Euros.")
  
      when 3
	     puts ("1 Peso equivale a 5.7 yenes")
		 print ("Ingresa una cantidad en pesos mexicanos: ")
		    moneda=gets().to_i
			c=moneda*yen
			   puts ("\t#{moneda} MXN son #{c} Yenes.")
  
      when 4
	     puts ("1 Peso equivale a 0.41 dolares HK")
		 print ("Ingresa una cantidad en pesos mexicanos: ")
		    moneda=gets().to_i
			c=moneda*dolarhk
			   puts ("\t#{moneda} MXN son #{c} Dolar HK.")
  
   else
      puts ("Escribiste una opcion invalida\n")

end
   
      print "\nDesea realizarlo otra vez. \n1.Si:\n2.No: "
      respuesta=gets().to_i
end while respuesta==1
